package com.video.selfads;

public interface OnInitializedSelfCompleteListener {
    void oninitializselfcomplete(Boolean var1, String message);
}