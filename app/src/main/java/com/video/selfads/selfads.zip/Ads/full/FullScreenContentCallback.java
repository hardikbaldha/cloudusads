package com.video.selfads.Ads.full;

public interface FullScreenContentCallback {
    void onclose();
}
