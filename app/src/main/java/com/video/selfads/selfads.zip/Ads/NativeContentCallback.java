package com.video.selfads.Ads;

public interface NativeContentCallback {
    void onAdDismissedFullScreenContent();
}
